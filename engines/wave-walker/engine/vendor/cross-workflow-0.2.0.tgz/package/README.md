# cross-workflow

`cross-workflow` compiles one typed, versioned workflow definition into two targets:

- a restricted, self-contained Claude Workflow `workflow.js`; and
- a JavaScript runner backed by `@openai/codex-sdk`.

Both targets execute the same portable interpreter. Target compilers only lower agents, mechanical effects, progress, and persistence into runtime-specific adapters. Unsupported behavior is a compile error.

Existing Workflow engines can instead use the native-contract compiler pair. Claude receives the validator-clean authoritative bundle byte-for-byte; Codex executes its instrumented form but exposes the same raw success value. This keeps installed callers stable while moving the engine's build and Codex execution behind the library.

## Quick start

```bash
npm ci
npm run build
npm run test
npm run compile
npm run compile:parity
npm run compile:wave-walker
npm run validate:claude
npm run smoke
```

Generated files land in `generated/claude/` and `generated/codex/`. The Codex runner imports the public `cross-workflow` package entry, so a relocated artifact resolves against an installed framework package instead of a compiler-output-relative `dist` path. The Claude artifact is the single `workflow.js`; its adjacent `package.json` exists only so Node 24 syntax checking matches Claude's auto-detected bundle grammar inside this ESM repository.

## Representative workflow

[`examples/api-rabbit-hole.workflow.ts`](examples/api-rabbit-hole.workflow.ts) implements the educational rabbit hole:

1. The logical `execution` agent finds an API entry point and fields. Defaults map it to Claude Sonnet and `gpt-5.6-terra`.
2. A checkpoint captures the validated plan.
3. One logical `collector` agent per field traces relationships concurrently. Defaults map it to Claude Haiku and `gpt-5.6-luna`.
4. `fs.statPaths` verifies returned source paths. Codex executes the effect directly in host Node. Claude calls the configured Haiku executor with a compiler-owned Python script and base64 JSON input.
5. Fan-in preserves field order and explicit branch errors.

Prompts live under [`prompts/`](prompts/). Repository and workflow data is appended in a JSON envelope; angle brackets are escaped so data cannot close the envelope.

That envelope is a structural boundary, not a proof that every model will resist every behavioral prompt-injection attempt. Treat repository content as untrusted, keep mechanical decisions in code/effects, and apply the target runtime's sandbox and approval policy.

Claude executor evidence is explicitly agent-attested, not host-attested. Compilation records warning `WF_EFFECT_004`; the script ID, fixed input/output schemas, and real run prove the bounded protocol, while the Workflow VM cannot independently prove that an LLM used Bash rather than returned equivalent output. Compile only to Codex when host attestation or a hard deadline around the executor agent is mandatory.

## Exact live parity fixture

[`examples/parity-proof.workflow.ts`](examples/parity-proof.workflow.ts) is deliberately schema-fixed. It runs one real collector agent, checkpoints, then stats one fixture path. `npm run smoke:parity` invokes both real providers and deep-compares `normalizeForParity()`; the final result and normalized node trace must be identical while evidence records Codex `direct` and Claude `executor-agent` lowering.

## Wave Walker compatibility program

[`examples/wave-walker.workflow.ts`](examples/wave-walker.workflow.ts) imports the complete, four-mode Wave Walker bundle through the versioned `harness-program` IR. The source is trusted build input with a pinned SHA-256—not arbitrary runtime script. Both compilers instrument that exact restricted program body: Claude keeps the native ambient harness, while Codex emulates `agent`, `parallel`, `pipeline`, `log`, `phase`, `workflow`, `args`, and `budget` with SDK threads.

The production authority remains Professor's modular `ENGINES/wave-walker/engine/src`. That engine consumes the packaged library at build time, compiles fresh side-by-side Claude/Codex candidates, proves the Claude candidate against the immutable legacy bundle on one exact Nervah merge-SHA walk, and switches only an explicit rollback-safe pointer. The vendored example here is a compatibility regression fixture, not a second production owner.

This compatibility path exists for mature Workflow engines whose arbitrary deterministic reducers cannot be represented faithfully as a declarative graph without rewriting their semantics. New workflows should use the graph IR. Imported bundles may contain prompts because they are already self-contained Workflow artifacts; the graph IR continues to require external prompt templates.

```bash
npm run validate:all
npm run smoke:wave-walker          # expected to fail loudly on this host's Bubblewrap defect
npm run smoke:wave-walker:unsafe-host # explicit danger-full-access execution
npm run smoke:wave-walker:claude   # actual Claude Workflow tool
```

The side-by-side Professor candidate was exercised against Nervah through both targets. The safe Codex verify run returned `DONE`/`UNPROVEN`, explicitly named the host's Bubblewrap inspection failure, and supplied no evidence; a separately acknowledged host-execution diagnostic and Claude Workflow independently confirmed the selected Company Map dispatch claim. A later full walk deliberately invoked the active pointer exactly once and exposed a caller-tool propagation failure: eight seats started, only three returned, and the task produced no terminal result. It is retained as a failed production probe, not success evidence; the corrected one-shot caller now grants only read-capable tools and refuses a duplicate invocation. Professor's promotion gate consumes that failure and the active pointer has been rolled back to immutable legacy. Raw results and boundaries are in [`evidence/runs/wave-walker-nervah.md`](evidence/runs/wave-walker-nervah.md) and [`evidence/runs/edge-case-charter.md`](evidence/runs/edge-case-charter.md).

Professor also runs the immutable legacy Claude bundle and the cross-workflow-generated Claude bundle through separate real headless Claude sessions before candidate activation. The comparator freezes every Git-indexed or nonignored-untracked repository byte across both runs and requires identical agent prompt/model/effort contracts, identical Workflow phase/agent/log topology, and the same grounded normalized terminal semantics. Git-ignored local state is explicitly outside that snapshot contract. It deliberately does not claim byte-identical stochastic reasoning prose; that distinction is recorded in the evidence rather than normalized away silently.

## Compile and run

```bash
npm run compile

node generated/codex/runner.mjs \
  --input examples/smoke-input.json \
  --output evidence/runs/codex-result.json \
  --root /home/reza/work/cross-workflow \
  --checkpoint-out evidence/runs/codex-checkpoint.json \
  --threads-out evidence/runs/codex-threads.json \
  --skip-git-repo-check
```

The default Codex mapping is read-only, network-disabled, web-search-disabled, approval `never`, and preserves the SDK's Git-repository check. The runner never silently weakens those settings.

This host cannot create Bubblewrap's loopback namespace. A host-execution diagnostic may opt out of the OS sandbox only with both `--unsafe-no-sandbox` and `--acknowledge-danger-full-access`. The runner prints a loud warning; such a run proves orchestration only, never sandbox enforcement. `--skip-git-repo-check` above is a separate explicit escape because this educational project is deliberately not a Git repository; omit it for normal repository-backed workflows.

### Codex subscription authentication

The Codex SDK starts the locally installed Codex CLI and reuses its cached login. A local `codex login` with ChatGPT therefore uses subscription access; no API key is required or passed by this framework. Confirm the active path with `codex login status` (this build was proven with `Logged in using ChatGPT`). API-key login is the separate usage-billed route. Unattended CI must provision an appropriate API key or supported workspace access token rather than copying personal credentials.

To resume portable workflow state:

```bash
node generated/codex/runner.mjs \
  --input examples/smoke-input.json \
  --checkpoint evidence/runs/codex-checkpoint.json \
  --skip-git-repo-check
```

Codex thread continuation is independently supported by `createCodexAdapter({ resumeThreads })`, keyed by node instance path. Each entry is a binding—not a bare thread ID—and is rejected unless instance path, workflow ID/version/hash, node ID, logical tier, and prompt hash all match. Generated graph and harness-program runners write current bindings with `--threads-out` and accept them with `--threads`. Portable checkpoints and native thread bindings are deliberately disjoint: a checkpoint skips completed node instances, while a thread binding continues a node that actually executes.

## Claude resume contract

Claude Workflow cannot persist files. A successful run returns full checkpoint objects. Cooperative resume means invoking the same bundle with:

```json
{
  "input": {
    "repositoryRoot": "/absolute/repository",
    "target": "path symbol",
    "maxFields": 2
  },
  "checkpoint": {
    "format": "cross-workflow-checkpoint/2",
    "...": "prior result checkpoint"
  }
}
```

The bundle logs only `⏺CKPT <name> <nodeId>`. The full state remains in the returned result. Crash recovery is Claude's native `resumeFromRunId` journal replay, outside the portable IR. Checkpoint v1 is rejected because v2 changed completion keys from static node IDs to instance paths. A checksum detects accidental corruption, not malicious rewriting; accept resume files only from authenticated storage. The native Wave Walker runner intentionally exposes no portable checkpoint input.

The Workflow tool currently serializes its `args` value as JSON text. Generated bundles accept either that string form or a direct object, parse once at the boundary, and then validate the canonical input schema.

## Parity contract

Deterministic adapters must match `normalizeRun()` exactly, including attempts and logical usage. Live providers can retry structured output below the visible adapter boundary, so live parity uses `normalizeForParity()`:

- final value or explicit error code;
- workflow/node/checkpoint topology by instance path;
- stable source-order fan-in.

Provider-native usage, thread IDs, and effect lowering evidence remain in `result.evidence`. They are deliberately not erased or misrepresented as equal.

## Real-runtime proof

- `npm run validate:claude` runs the vendored byte-identical Professor Claude Workflow validator against the generated bundle and prints its pinned SHA-256. `CROSS_WORKFLOW_CLAUDE_VALIDATOR` may point at an installed source copy; hash drift fails loudly.
- `npm run smoke:codex` uses local Codex authentication and the real SDK.
- `npm run smoke:claude` invokes the installed Claude CLI with the real Workflow tool and the generated script.
- `npm run smoke:parity` executes the schema-fixed workflow through both real providers and rejects any normalized trace/result difference.
- `npm run smoke:wave-walker:unsafe-host` and `npm run smoke:wave-walker:claude` execute the migrated Wave Walker against Nervah through both targets; only the former deliberately opts out of sandboxing.
- [`evidence/requirements.md`](evidence/requirements.md) maps every requested property to current proof.

## Reference

- [`docs/_index.md`](docs/_index.md) — architecture, API, authoring, capabilities, and migration.
- [Official Codex SDK documentation](https://learn.chatgpt.com/docs/codex-sdk)
- [Official Codex authentication documentation](https://learn.chatgpt.com/docs/auth)
- [Claude Code tools reference](https://code.claude.com/docs/en/tools-reference)

The restricted Claude Workflow VM is not currently described in Claude Code's public tools reference. Its installed engine sources and validator are the contract used here: ambient `agent`, `parallel`, `pipeline`, `log`, `phase`, `workflow`, `args`, and `budget`; no imports, Node APIs, network APIs, clocks, randomness, or host filesystem.
