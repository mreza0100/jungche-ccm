# Migration example

## Hand-authored Claude Workflow

```js
const plan = await agent(plannerPrompt, {
  model: "sonnet",
  schema: plannerSchema,
});
const traces = await parallel(
  plan.fields.map(
    (field) => () =>
      agent(tracePrompt(field), { model: "haiku", schema: traceSchema }),
  ),
);
return { plan, traces };
```

## Canonical IR

```ts
defineWorkflow({
  irVersion: "1.0",
  models: {
    claude: {
      execution: { model: "sonnet", effort: "high" },
      collector: { model: "haiku", effort: "medium" },
      judgment: { model: "opus", effort: "high" },
    },
    codex: {
      execution: {
        model: "gpt-5.6-terra",
        effort: "high",
        sandboxMode: "read-only",
        approvalPolicy: "never",
        networkAccess: false,
        webSearch: "disabled",
      },
      collector: {
        model: "gpt-5.6-luna",
        effort: "medium",
        sandboxMode: "read-only",
        approvalPolicy: "never",
        networkAccess: false,
        webSearch: "disabled",
      },
      judgment: {
        model: "gpt-5.6-sol",
        effort: "high",
        sandboxMode: "read-only",
        approvalPolicy: "never",
        networkAccess: false,
        webSearch: "disabled",
      },
    },
  },
  root: {
    kind: "sequence",
    id: "root",
    steps: [
      {
        kind: "agent",
        id: "plan",
        prompt: "planner",
        modelTier: "execution",
        input,
        outputSchema: plannerSchema,
        capabilities,
        retry,
      },
      { kind: "checkpoint", id: "planned", name: "after-plan" },
      {
        kind: "fanOut",
        id: "traces",
        items: fields,
        itemName: "field",
        maxConcurrency: 3,
        failureMode: "collect",
        body: traceAgent,
      },
      { kind: "fanIn", id: "joined", input: traceValues, operation: "collect" },
    ],
  },
});
```

Move prompt prose to external files and pass untrusted data through expressions. Replace arbitrary shell work with a catalog effect. Declare capabilities and target mappings. Add an explicit failure policy and checkpoint boundary. Compile both targets, then compare exact deterministic traces and live normalized topology.

The complete, executable migration is `examples/api-rabbit-hole.workflow.ts`.
