# Architecture

## One semantic core

`src/runtime/core.ts` is JavaScript-compatible TypeScript with no runtime imports. Codex imports its compiled module. The Claude compiler strips its sole module exports and embeds the same code into the bundle. Sequence, parallel ordering, branches, loops, fan-out/fan-in, retries, explicit error values, events, and checkpoints therefore have one implementation.

Each node has a static `id`; each execution has an `instancePath`. Resume memoization uses instance paths, so loop iterations and fan-out branches cannot collide. Parallel branches receive isolated state and event buffers. The join merges buffers in source index order, independent of completion timing.

## Target adapters

The Codex adapter uses `startThread()` or `resumeThread()`, `runStreamed()`, per-turn output schemas and abort signals, logical model mappings, working directory, sandbox, approval, network, and web-search controls. Native stream events feed an optional observer; token usage, thread IDs, and validated resume bindings remain runtime evidence. A resumed thread must match SHA-256 workflow and prompt identities plus workflow ID/version, instance path, node ID, and logical tier or execution fails with `thread_resume_incompatible`.

The Claude adapter uses only ambient Workflow globals. It calls `agent()` with a schema and logical model mapping, `parallel()` for concurrent batches, `phase()` for the UI, and `log()` for compact progress/checkpoint notices. Subagents inherit the outer Claude caller's enabled tools. The bundle declares repository-read semantics but cannot grant `Read` or Git commands to itself; launchers must satisfy that capability with a minimal read-only caller tool policy.

Retry attempts live in the semantic core. Nonzero backoff calls an adapter capability: Codex supplies a host timer, while Claude compilation rejects it because the Workflow VM exposes no deterministic timer. Codex distinguishes caller cancellation, configured timeout, and provider turn failure as separate error codes.

Codex fail-fast parallelism uses a shared portable cancellation token. The first failing branch aborts active SDK turns, prevents retries/backoff in siblings, waits for them to settle, and emits no events after the terminal failure. Claude compilation rejects fail-fast because its ambient `parallel()` primitive cannot cancel sibling agents faithfully.

Capability declarations express required semantics. A graph agent without `agent.repository-read` receives no Claude `agentType` and runs from a disposable empty Codex working directory; an agent declaring it runs against the configured repository root. The current Codex SDK does not expose a per-thread shell-tool deny list, so capability declarations are not a substitute for an OS sandbox or an authorization boundary. Mechanical work that must be identical belongs in the fixed effect catalog.

## Mechanical effects

The effect catalog contains compiler-owned mechanisms. Authors reference an effect ID and typed input; they cannot provide a script or command.

`json.canonicalize` executes directly on both targets. `fs.statPaths` executes in Codex host code. Claude receives the same bounded contract through an executor agent: fixed script, fixed script ID, base64 JSON input, command timeout, and exact output envelope. The executor performs a decided mechanism and cannot redesign it.

The Claude lowering is agent-attested. Its command timeout is an executor instruction because the VM cannot impose a timer around `agent()`, and the script ID identifies the selected mechanism rather than cryptographically proving execution. The compiler emits `WF_EFFECT_004`; users requiring host attestation must reject that warning or target Codex only.

Both implementations reject absolute child paths, `..` escape, NUL, excess path count/length, and symbolic-link escape. Direct and delegated failures retain the same error codes.

## Restricted-program compatibility IR

`HarnessProgramDefinition` carries a reviewed, validator-clean Workflow bundle, its SHA-256 pin, provenance, model aliases, schemas, and capability contract. The compiler rejects pin drift and extra module syntax, then instruments only the ambient harness calls. The resulting Claude bundle and Codex runner contain the same program body. Canonical input and output schemas are enforced at the program boundary. Agent schemas are lowered to the strict closed-object form required by Codex structured output, including explicit nullable wrappers for originally optional fields, on both targets.

This is a migration bridge for existing engines with arbitrary deterministic JavaScript. It is not an arbitrary-script escape hatch: program source is trusted build input, integrity-pinned, self-contained, and separately validator-gated.

The bridge can preserve ambient agent calls, but it cannot infer mechanical shell requirements hidden in natural-language prompts. A migrated engine that tells agents to run Git commands must pair its `agent.repository-read` declaration with a caller policy that actually enables read-only Git/Read/Glob/Grep operations. The Phase-2 production probe demonstrated the failure mode: an outer `--tools Workflow` restriction propagated to subagents, five seats exhausted the task window, and no terminal result existed. The reproducible caller now grants only read-capable commands and rejects zero-byte task output.

## Results and evidence

The portable result holds status, value or explicit error, normalized trace, logical usage, and checkpoints. Runtime evidence separately records direct versus executor-agent lowerings, all five native SDK token counters (including cache writes), thread IDs, thread-resume bindings, and implementation IDs.

`normalizeRun()` is the strict deterministic-adapter comparison. `normalizeForParity()` is the live-provider comparison and excludes attempt events and usage because providers have different invisible schema-retry behavior.

The open-ended rabbit-hole workflow proves representative orchestration. The schema-fixed parity workflow proves exact real-provider comparison: identical final mechanical evidence and normalized topology, with target-specific lowering evidence retained rather than normalized away.

## Checkpoints

Checkpoint format v2 stores workflow ID/hash, instance-path completion set, memoized results, state, prior trace, logical usage, and an FNV-1a checksum. Resume requires the same canonical input and validates the file boundary, state structure, completion/memo relationship, event sequence, usage counters, checksum, and every resumed agent/effect value against its node output schema. Corruption and artifact mismatch are explicit errors. The checksum detects accidental corruption; it is not a MAC and checkpoints from untrusted writers require authenticated storage. Checkpoints inside parallel, fan-out, or loop work fail compilation because a branch-local snapshot cannot faithfully reconstruct joined state.

Codex atomically persists checkpoints with mode `0600` through a unique, exclusively created same-directory temporary file. Persistence refuses a symbolic-link destination, flushes the temporary file before rename, and removes an uncommitted temporary file on failure. Claude returns checkpoints to its caller. Native Claude run journaling and Codex thread persistence remain target facilities rather than pretending to be identical portable storage.
