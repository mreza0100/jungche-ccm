# Reference index

| Topic        | File                                         | Covers                                                         |
| ------------ | -------------------------------------------- | -------------------------------------------------------------- |
| Architecture | [architecture.md](architecture.md)           | Portable interpreter, adapters, events, checkpoints, parity    |
| API          | [api-reference.md](api-reference.md)         | Public authoring, compiler, runtime, and adapter APIs           |
| Authoring    | [authoring-guide.md](authoring-guide.md)     | Definition workflow, schemas, nodes, prompts, verification      |
| Capabilities | [capability-matrix.md](capability-matrix.md) | Direct, delegated, unsupported behavior, and authentication     |
| Migration    | [migration-example.md](migration-example.md) | Moving a hand-authored Claude workflow to the canonical IR      |
