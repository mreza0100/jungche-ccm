# Capability matrix

| Capability                          | Claude Workflow                           | Codex SDK                                | Compile behavior                              |
| ----------------------------------- | ----------------------------------------- | ---------------------------------------- | --------------------------------------------- |
| Structured agent call               | Direct `agent()`                          | Direct streamed thread                   | Supported                                     |
| Repository read                     | Caller-enabled Read/Glob/Grep or read-only Git tools | Configured root + read-only sandbox      | Required capability; caller must honor it     |
| Agent without repository read       | No repository-oriented `agentType`        | Disposable empty working directory       | Accidental-root isolation; not an OS ACL      |
| Per-agent model/effort              | Workflow aliases                          | Model ID and reasoning effort            | Independently mapped                          |
| Ordered parallelism                 | Ambient `parallel()`                      | Host promises with bounded batches       | Supported                                     |
| True fail-fast sibling cancellation | No faithful primitive                     | Shared abort token; settle before return | Claude compile error                          |
| Sequence/branch/loop/fan-out/fan-in | Portable interpreter                      | Portable interpreter                     | Supported                                     |
| Deterministic transforms            | Direct bundle code                        | Direct host code                         | Supported                                     |
| `json.canonicalize`                 | Direct bundle code                        | Direct host code                         | Supported                                     |
| `fs.statPaths`                      | Haiku executor, fixed script              | Direct Node filesystem                   | Supported with recorded lowering              |
| Agent hard timeout                  | No deterministic timer                    | Abort signal                             | Claude compile error                          |
| Retry sleep/backoff                 | No deterministic timer                    | Host timer possible                      | Nonzero portable backoff fails Claude compile |
| Mechanical command timeout          | Agent instructed to use command timeout   | Host deadline/effect                     | Claude lowering is agent-attested             |
| Cancellation                        | Native run cancellation/cooperative graph | Abort signal                             | Runtime-specific evidence                     |
| Progress                            | `phase()` and `log()`                     | callback plus SDK stream                 | Supported                                     |
| Logical usage                       | Agent/effect attempt counters             | Same                                     | Supported                                     |
| Native token usage                  | Not returned by `agent()`                 | `turn.completed` usage                   | Evidence sidecar, not fabricated              |
| Portable checkpoint                 | Returned object and compact log           | Returned object and optional atomic file | Supported                                     |
| Crash resume                        | Native Workflow run journal               | Codex session store                      | Target-native, not normalized                 |
| Agent thread resume                 | Native journal replay                     | Validated binding per instance           | Target-native; mismatches fail                 |
| Checkpoint inside branch/loop       | Cannot reconstruct joined state           | Same portable limitation                 | Compile error                                 |
| Arbitrary author script             | Forbidden                                 | Forbidden                                | Compile error                                 |
| Network/web search                  | Agent/runtime policy                      | Explicit thread settings                 | Must be declared and faithfully mapped        |

Claude's bundle validator also rejects imports, CommonJS, multiple exports, computed meta, `Date.now`, `Math.random`, argless `new Date`, Buffer, process, fetch, crypto, and URL host globals.

Capabilities are required-function declarations, not a universal tool allowlist. Codex 0.147.0 exposes sandbox, approval, working-directory, additional-directory, network, and web-search controls, but no per-thread shell-tool deny list. The empty working directory reduces accidental repository coupling; use an external OS sandbox for adversarial confidentiality boundaries. Unsafe host execution requires the paired `--unsafe-no-sandbox --acknowledge-danger-full-access` flags, proves host execution only, and is never sandbox-enforcement evidence. Git-repository checks remain enabled unless `--skip-git-repo-check` is separately supplied.

Claude Workflow subagents inherit the caller's enabled-tool surface. A caller that launches a repository-reading bundle with `--tools Workflow` has violated the bundle's declared `agent.repository-read` requirement: subagent `Read` calls are disabled and Git mechanics do not exist. Headless callers must enable the minimum read-only surface required by the workflow, for example `Read,Glob,Grep` plus narrowly matched `Bash(git diff *)`, `Bash(git show *)`, `Bash(git rev-parse *)`, `Bash(git log *)`, `Bash(git cat-file *)`, and `Bash(git ls-files *)`, while denying Write/Edit/NotebookEdit. This permission propagation is external to `workflow.js`; compilation cannot grant host tools.

## Authentication boundary

The Codex SDK launches the local Codex CLI. Local ChatGPT sign-in provides subscription access and its cached session is reused; API-key login instead uses metered API billing. The framework never reads or copies credentials. CI must provision a supported non-interactive authentication method explicitly.
