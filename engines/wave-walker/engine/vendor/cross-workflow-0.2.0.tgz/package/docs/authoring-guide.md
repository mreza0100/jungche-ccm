# Authoring guide

## Define the contract

Start from `examples/api-rabbit-hole.workflow.ts`. Choose a lowercase workflow ID and stable version. Define closed input/output schemas with `required` and `additionalProperties: false` at external boundaries.

The portable schema subset supports type, properties, required, additionalProperties, items, length/item/number bounds, enum, const, anyOf, and oneOf. Each schema is limited to 32 KiB, 16 nesting levels, and 64 properties per object.

## Register prompts

Store every substantial LLM prompt under `prompts/`. Load it with a stable source label. Prompts describe judgment; code computes limits, ordering, validation, hashes, effects, and error policy.

Agent data is never interpolated into prompt instructions. The runtime appends canonical JSON inside `workflow-data`; angle brackets are escaped so data cannot close that envelope. This proves structural separation, not universal behavioral resistance to prompt injection. Keep untrusted content scoped, request structured evidence, and leave deterministic or privileged operations to catalog effects.

## Map logical models

Map `judgment`, `execution`, and `collector` independently for Claude and Codex. Defaults are configuration, not an equivalence claim. Workflow definitions can override every mapping.

Claude accepts Workflow aliases `haiku`, `sonnet`, and `opus`. Codex accepts a model ID plus effort, sandbox, approval, network, and web-search settings.

## Compose nodes

Use unique static node IDs. Use `sequence` for dependencies, `parallel` for independent fixed branches, and `fanOut` for data-driven branches. Both parallel forms join in source order.

Set bounded retries. Portable Claude retries have no sleep because the VM exposes no deterministic timer. A hard agent timeout compiles to Codex but fails Claude compilation. Mechanical effect timeouts lower through the Claude executor command.

`fail-fast` parallelism is available to Codex. The first failure cancels sibling turns and retry waits, waits for settlement, and freezes the trace before returning the terminal error. Claude compilation rejects it because the Workflow primitive cannot cancel sibling agents; use `collect` for a dual-target definition.

Use `failure.mode: return-error` when later graph logic can handle a node error. Use parallel/fan-out `collect` to preserve partial branch failures as named data. Never translate a failure into an empty array.

Place checkpoints only in sequential graph positions after a stable boundary. Resume by passing the checkpoint object from a prior result. Keep checkpoint data appropriate for the caller's storage policy.

## Declare capabilities

List workflow-level requirements and per-agent capabilities. Run validation for both targets before compilation. A missing direct or delegated lowering is a compilation failure with a remedy.

Capabilities declare what an agent needs; they are not a general authorization system. Without `agent.repository-read`, the compilers avoid the repository-oriented Claude agent type and give Codex an empty disposable working directory. Codex's SDK currently exposes sandbox and directory controls but not a per-thread shell-tool deny list, so use an external OS boundary where hostile absolute-path reads matter.

For Claude headless launchers, `agent.repository-read` is also a caller obligation. Workflow subagents inherit the outer `--tools` surface. Enable only the necessary read tools and read-only Git command patterns; deny editing tools. Launching a repository workflow with only `Workflow` enabled is a capability violation and must fail loud rather than be interpreted as an empty inspection.

Authors cannot supply shell commands or scripts. Add a fixed effect implementation and both target lowerings to the framework when a new mechanical capability is required.

Treat Claude executor output as agent-attested evidence. If policy requires host-attested execution or a hard executor-agent deadline, treat `WF_EFFECT_004` as disqualifying and compile only the direct Codex target.

## Import an existing Workflow engine

Use `defineHarnessProgram()` only for a reviewed, self-contained bundle already accepted by Claude's validator. Pin its SHA-256 and provenance. The compatibility compiler preserves its deterministic JavaScript and ambient-call topology while mapping Claude model/effort aliases to logical target tiers. Refreshing the source and pin is a deliberate migration event that must rerun both validators and both real-runtime smokes.

Codex/OpenAI structured output requires closed object schemas. The compatibility compiler recursively closes objects and represents optional properties as required nullable values on both generated targets, preserving cross-target result shape.

## Verify

```bash
npm run lint
npm run test
npm run validate:claude
npm run smoke
npm run smoke:parity
```

Use deterministic adapters for exact full-trace golden tests. Use a schema-fixed workflow with `normalizeForParity()` when final values must compare across real providers. Preserve raw evidence for debugging and accounting.
