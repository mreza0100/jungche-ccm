# API reference

## Authoring

`defineWorkflow(definition)` preserves and type-checks a `WorkflowDefinition`.

`loadPrompt(id, URL, source?)` reads an external prompt. Supply a stable repository-relative `source` so workflow hashes do not depend on the author's home directory.

`WorkflowDefinition` requires IR/version identity, input/output schemas, prompt registry, target model mappings, capability requirements, executor-agent policy, and one root node.

`defineHarnessProgram(definition)` preserves a `HarnessProgramDefinition`: a versioned, integrity-pinned restricted Workflow bundle plus schemas, target mappings, alias mappings, capabilities, and source provenance.

## Nodes

| Kind         | Contract                                                                                                |
| ------------ | ------------------------------------------------------------------------------------------------------- |
| `sequence`   | Runs children in order; result is the final child value                                                 |
| `parallel`   | Runs branches concurrently, joins in source order, fail-fast or collect                                 |
| `agent`      | External prompt, data expression, output schema, logical model tier, capabilities, retry/failure policy |
| `effect`     | Compiler-owned portable effect, input/output contract, timeout, retry/failure policy                    |
| `transform`  | `identity`, `pluck`, `flatten`, `sort`, `unique`, or `count`                                            |
| `branch`     | Selects `then` or `else` through a portable predicate                                                   |
| `loop`       | Bounded body execution until a predicate matches                                                        |
| `fanOut`     | Runs one isolated body instance per input item with bounded concurrency                                 |
| `fanIn`      | Collects, flattens, or merges object results                                                            |
| `nested`     | Names a subgraph without changing semantics                                                             |
| `checkpoint` | Emits a resumable v2 state snapshot in sequential work                                                  |
| `emit`       | Adds a deterministic user event                                                                         |

`ValueExpression` reads from `input`, `current`, node `values`, or branch/loop `local` state; it also builds literal arrays and objects. `Predicate` supports truthiness, existence, canonical equality, numeric comparisons, and/or/not.

## Compilation

`validateWorkflow(definition, target)` returns diagnostics and per-effect lowerings without throwing.

`compileClaude(definition)` returns self-contained bundle code and a manifest.

`compileCodex(definition)` returns a package-relative SDK runner and a manifest.

`compileHarnessProgramClaude(definition)` and `compileHarnessProgramCodex(definition)` compile the same restricted program body to native ambient Workflow globals or an SDK-backed emulation.

`compileHarnessProgramClaudeNative(definition)` validates and emits an authoritative native Workflow bundle byte-for-byte, preserving its raw return contract. `compileHarnessProgramCodexNative(definition)` runs the same validated program through the portable Codex harness but unwraps successful results to that same raw contract; compiler/harness failures become explicit `{ status: "FAILED", detail }` results and a nonzero runner exit. Use this pair when integrating the library into an existing Workflow engine whose callers already consume its native result shape.

`workflowHash(definition)` returns the stable SHA-256 definition identity. Compiler version is recorded independently.

`validateWorkflow()` fails closed on malformed JavaScript inputs and returns actionable diagnostics instead of throwing for invalid definition shapes. `CompileError.diagnostics` contains code, path, message, and remedy. Compilation fails when any error diagnostic exists.

Warnings remain in generated manifests and are printed by the CLI. `WF_EFFECT_004` marks agent-attested Claude mechanical effects; `WF_POLICY_001` marks unrestricted unattended Codex mappings.

## Runtime

`executeWorkflow(definition, input, adapter, { workflowHash, checkpoint? })` always returns an explicit `ok` or `error` result.

`normalizeRun(result)` retains full deterministic trace and logical usage while removing runtime evidence.

`normalizeForParity(result)` compares live topology, final value, and error code without provider-specific attempts or usage.

`canonicalJson(value)` sorts object keys recursively. `identityHash(value)` computes SHA-256 for workflow/prompt/thread identity in Node targets. `portableHash(value)` computes the restricted-runtime FNV-1a checksum used only for accidental checkpoint-corruption detection; it is never an adversarial identity.

## Codex adapter

`createCodexAdapter(options)` accepts definition, working directory, optional SDK client, explicit Git-repository check policy, explicit unsafe sandbox override, per-instance thread bindings, cancellation signal, progress/SDK observers, and checkpoint file.

Each `AgentThreadResumeBinding` contains `threadId`, instance path, workflow ID/version/hash, node ID, logical model tier, and prompt hash. A mismatch fails before `resumeThread()` is called. Successful run evidence returns current bindings for durable storage. Generated runners accept a JSON binding map with `--threads`, persist bindings with `--threads-out`, and optionally persist the JSON result with `--output`.

`NativeUsage` records SDK input, cached-input, cache-write-input, output, and reasoning-output tokens. All five counters accumulate across nodes; a cache-write-only turn remains visible rather than collapsing to `null`.

Before an SDK turn, the adapter adds an explicit JSON Schema `type` when a `const` or homogeneous `enum` makes that type unambiguous. This is semantics-preserving and satisfies Codex 0.147's response-schema requirement without narrowing the canonical schema.

`createCodexProgramHarness(options)` exposes the Codex implementation of the restricted ambient globals. It requires the compiled workflow hash and applies the same validated thread-binding contract; `onThreadBinding` receives successful bindings.

The portable adapter can expose `backoff(milliseconds)`. A workflow that requests nonzero retry backoff fails explicitly with `backoff_unavailable` if the selected adapter cannot honor it.

Checkpoint persistence uses a mode-`0600`, uniquely and exclusively created same-directory temporary file followed by atomic rename; symbolic-link destinations are refused. `readCheckpoint(file)` parses and validates the untrusted file boundary; checksum, workflow identity, and memoized node outputs are validated by `executeWorkflow()`.

Resume also requires canonical equality with the original input. Mismatch is `checkpoint_input_mismatch`; malformed or schema-invalid checksum-correct state is `checkpoint_corrupt`; older formats are `checkpoint_incompatible`. The checksum is not authentication, so resume artifacts require trusted storage.

`runHostEffect(request)` executes the fixed host effect catalog. `FS_STAT_PATHS_SCRIPT` and `FS_STAT_PATHS_SCRIPT_ID` are exported for compiler lowering and audit.
